INSERT INTO prenotazione(codicevolo, documento)  VALUES ('EGZ85567','YH54987708');
INSERT INTO prenotazione(codicevolo, documento)  VALUES ('FLZ64705','YH54987708');
INSERT INTO prenotazione(codicevolo, documento)  VALUES ('KFZ64396','YH54987708');
INSERT INTO prenotazione(codicevolo, documento)  VALUES ('RJC30409','YH54987708');
