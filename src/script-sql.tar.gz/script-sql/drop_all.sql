﻿drop table posto cascade;
drop table imbarco cascade;
drop table passeggero cascade;
drop table prenotazione cascade;
drop table volo cascade;
drop table biglietto cascade;
drop table tratta cascade;
drop function update_time_richiesta;
drop function update_time_biglietto;